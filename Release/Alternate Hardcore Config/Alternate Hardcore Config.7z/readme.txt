Alternate config for Progressive Map Access.  

This config requires the player to complete a specific mission on each map, other than ground zero before it unlocks.

The missions I picked I picked either because they would require the player to extract at least once or if I couldn't find
a mission that required that, would require the player to do a fair amount of work.  I also wanted to pick a mission that
unlocked relatively early on a map if possible.

Customs: Background Check
Factory: Scout
Woods: Search Missions
Interchange: Big Sale
Streets: Cease Fire!
Shoreline: Fishing Gear
Lighthouse: Long Road
Reserve: Disease History
Labs: Beneath The Streets

Unlocking Customs and Woods could be difficult as whichever one you start with would require the player to start at
Ground Zero, transit to Streets, then to Interchange, then to Customs.  If you picked to unlock Woods first would further
require transiting to Factory then to Woods itself.

For those who want a hardcore expirence without having to comb a wiki, here it is.